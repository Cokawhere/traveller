import 'package:traveller/enums/user_enum.dart';
import 'package:traveller/models/user_model.dart';

class AuthService {
  static List<User> _users = [];
  static User? _currentUser;

  static bool register(String name, String email, String password, UserRole role) {
    // Check if user already exists
    if (_users.any((user) => user.email == email)) {
      return false;
    }
    
    _users.add(User(
      name: name,
      email: email,
      password: password,
      role: role,
    ));
    return true;
  }

  static bool login(String email, String password) {
    try {
      _currentUser = _users.firstWhere(
        (user) => user.email == email && user.password == password,
      );
      return true;
    } catch (e) {
      return false;
    }
  }

  static User? getCurrentUser() => _currentUser;

  static void logout() {
    _currentUser = null;
  }
}