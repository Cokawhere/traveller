import 'package:traveller/enums/user_enum.dart';

class User {
  final String email;
  final String password;
  final UserRole role;
  final String name;

  User({
    required this.email,
    required this.password,
    required this.role,
    required this.name,
  });
}